package com.extrabeat.bean;

public enum Role {
    ADMIN,
    CUSTOMER
}
